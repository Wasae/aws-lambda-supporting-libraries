const puppeteer = require('puppeteer');
const AWS = require('aws-sdk');

// AWS.config.update({
//     accessKeyId: 'your-access-key-id',
//     secretAccessKey: 'your-secret-access-key',
//     region: 'your-region' // e.g., us-east-1
// });

const s3 = new AWS.S3();

async function generateAndUploadPDF(html) {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();

    // Set the content of your HTML and CSS
    const content = html;
    await page.setContent(content);

    // Generate PDF
    const pdfBuffer = await page.pdf({ format: 'A4' });

    // Upload PDF to S3
    const params = {
        Bucket: 'your-s3-bucket', //bucket name here
        Key: 'path/to/your/file.pdf', //subfolder here & name of file
        Body: pdfBuffer
    };

    const uploadResult = await s3.upload(params).promise();

    console.log('PDF uploaded to S3:', uploadResult.Location);

    await browser.close();
    return uploadResult;
}





module.exports.handler = async(event) => {
    try {
        var reqParam = JSON.parse(event.Payload)
        var resp = await generateAndUploadPDF(reqParam.Content)
        return {
            Status: true,
            body: JSON.stringify({
                Message: "Upload Complete",
                S3Info: resp
            }),
        };
    } catch (error) {
        return {
            Status: false,
            body: JSON.stringify({
                Message: "Upload Failed",
                S3Info: err
            }),
        };
    }
};