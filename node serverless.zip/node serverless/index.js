const puppeteer = require('puppeteer');

(async() => {
    const browser = await puppeteer.launch({ headless: 'false' });
    const page = await browser.newPage();

    // Set the content of your HTML and CSS
    const content = `<html><body><h1>Hello, World!</h1></body></html>`;

    await page.setContent(content);

    // Generate PDF
    await page.pdf({ path: 'output.pdf', format: 'A4' });

    await browser.close();
})();